#include "itrace.h"
#include "../cstrike/sdk/interfaces/iengineclient.h"
#include "../cstrike/sdk/interfaces/cgameentitysystem.h"
#include "../cstrike/sdk/interfaces/igameresourceservice.h"
